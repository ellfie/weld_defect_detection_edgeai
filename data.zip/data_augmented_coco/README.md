# Augmented Weld Defect Dataset (COCO Format)

## Directory Structure
```
data_augmented_coco/
├── training/
│   ├── _annotations.coco.json
│   └── [training images with prefix]
└── testing/
    ├── _annotations.coco.json
    └── [testing images with prefix]
```

## Dataset Details
- Images have flattened naming: `{folder}_{original_name}.jpg`
- Original images + augmented versions (3x per image)
- Train/Test split: 80/20
- **Bounding boxes are updated after each augmentation**

## COCO JSON Format
Standard COCO format with:
- **images**: Image metadata (id, file_name, width, height)
- **annotations**: Bounding boxes (id, image_id, category_id, bbox, area)
- **categories**: Label definitions (id, name)
- **bbox format**: [x, y, width, height] in pixels

## Upload to Edge Impulse
```bash
edge-impulse-uploader --category training data_augmented_coco/training
edge-impulse-uploader --category testing data_augmented_coco/testing
```

## Use with Other Frameworks
Compatible with:
- YOLOv8
- Detectron2
- MMDetection
- PyTorch/TensorFlow object detection models

## Augmentations Applied
- Horizontal/Vertical flips
- Rotations (±15°)
- Brightness/Contrast adjustments
- Hue/Saturation/Value changes
- Gaussian blur and median blur
- **All bounding boxes are automatically transformed to match augmented images**
